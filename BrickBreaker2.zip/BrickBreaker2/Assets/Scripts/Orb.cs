﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Orb : MonoBehaviour {

	[SerializeField] private float speedX = 0f;
	[SerializeField] private float speedY = 0f;
	private bool inPlay = false;
	private GameController game;
 	public const float FLOOR = -15f;
	public const float LEFT_WALL = -14.3f;
	public const float RIGHT_WALL = 16.6f;
	public const float CEILING = 10.9f;
	// randomize speed?

	void Start () {
		game = GameObject.Find("GameController").GetComponent<GameController>();
	}
	
	void Update () {
		if (inPlay) {
			UpdateSpeed();
			
			if (transform.position.y <= FLOOR) {
				DestroySelf();
			}
				
		} else {
			Launch();
		}
	}

	// what is difference between OnTrigger and OnCollision?
	void OnCollisionEnter(Collision coll) {
		GameObject collidedWith = coll.gameObject;
		// How may I change this? Lots of repetiton.
		if (collidedWith.tag == "wall") {
			speedX = -speedX;
		} else if (collidedWith.tag == "ceiling" ||
			collidedWith.tag == "paddle") {
			speedY = -speedY;
		} else if (collidedWith.tag == "brick") {
			speedY = -speedY;
			Destroy(collidedWith);
		}
	}

	private void Launch() {
		if (Input.GetMouseButtonDown(0)) {
			speedX = 18f;
			speedY = 18f;
			inPlay = true;
		}
	}

	private void DestroySelf() {
		Destroy(this.gameObject);
		inPlay = false;
	}

	public void UpdateSpeed() {
		Vector3 pos = transform.position;
		pos.x += speedX * Time.deltaTime;
		pos.y += speedY * Time.deltaTime;
		transform.position = pos;
	}

	// will be used as a reference point to tell game controller when orb is missed.
	public bool LostOrb() {
		return inPlay;
	}

}
