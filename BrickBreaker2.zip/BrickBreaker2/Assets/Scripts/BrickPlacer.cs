﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BrickPlacer : MonoBehaviour {

	public GameObject brickPrefab;
 	private List<GameObject> bricks;
 	public float spacingX = 3f;
 	public float spacingY = 3f;
 	// For now: have 10 bricks. Then, once we have hierarchy for levels then we will change.
 	public int numBricks = 10;

 	private const float EDGE = 14f;
 	private const float CEILING = 11f;
	void Start () {
		bricks = new List<GameObject>();
		Vector3 startPos = new Vector3(-EDGE + (float)0.5, CEILING, 0);
		for (int i = 0; i < numBricks; i++) {
			GameObject brick = Instantiate(brickPrefab) as GameObject;
			bricks.Add(brick);
			float posX = (spacingX * i) + startPos.x;
			brick.transform.position = new Vector3(posX, startPos.y, startPos.z);
		}
	}
	
	void Update () {
		
	}
}
