﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GameController : MonoBehaviour {

	// Game World Data
	public const float FLOOR = -15f;
	public const float LEFT_WALL = -14.5f;
	public const float RIGHT_WALL = -16.75f;

	// Game Objects
	[SerializeField] private Model m;
	[SerializeField] private GameObject orbPrefab;
	[SerializeField] private GameObject padPrefab;


	void Start () {
		GameObject orb = Instantiate(orbPrefab) as GameObject;
		GameObject pad = Instantiate(padPrefab) as GameObject;
	}
	
	
	void Update () {

	}



}
