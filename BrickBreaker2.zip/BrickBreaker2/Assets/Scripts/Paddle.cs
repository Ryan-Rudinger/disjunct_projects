﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Paddle : MonoBehaviour {

	// Does this belong here? Could there be a Bounds Class? The class that holds the Floor, the walls, etc.
	// Or is that extraneous?
	private const float EDGE = 13.5f;

	void Start () {
		
	}
	
	void Update () {
		ChangePositionWithMouse();
	}

	private void ChangePositionWithMouse() {
		Vector3 mousePos2D = Input.mousePosition;
		mousePos2D.z = -Camera.main.transform.position.z;
		Vector3 mousePos3D = Camera.main.ScreenToWorldPoint(mousePos2D);
		Vector3 pos = this.transform.position;
		pos.x = Mathf.Clamp(mousePos3D.x, -EDGE, EDGE);
		// pos.x = mousePos3D.x;
		this.transform.position = pos;
	}

}
