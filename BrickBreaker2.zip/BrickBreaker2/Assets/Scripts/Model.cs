﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Model : MonoBehaviour {

	private static int level = 1;
	public const float FLOOR = -15f;

	void Start () {
		
	}

	void Update () {
		
	}

	// public bool OrbMissed() {

	// }

	// public float GetFloor() {
	// 	return FLOOR;
	// }
}
